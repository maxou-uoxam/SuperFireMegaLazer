#ifndef SCORE_HPP_INCLUDED
#define SCORE_HPP_INCLUDED

void checkScore(int score, float *taux_spawn);

#endif // SCORE_HPP_INCLUDED
