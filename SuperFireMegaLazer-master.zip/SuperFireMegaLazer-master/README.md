# SuperFireMegaLazer
C++ project using SFML library. Student project made in 4 days.
